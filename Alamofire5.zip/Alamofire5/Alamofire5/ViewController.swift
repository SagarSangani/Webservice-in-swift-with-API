//
//  ViewController.swift
//  Alamofire5
//
//  Created by admin on 16/11/17.
//  Copyright © 2017 360techno. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet var nameTF: UITextField!
    @IBOutlet var passTF: UITextField!
    @IBOutlet var emailTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func RegistorBTN(_ sender: Any) {
        
        
        let Dic = ["Username":nameTF.text!,"Password":passTF.text!,"Email":emailTF.text!]
        
        //Alamofire.request("http://192.168.1.19/skeleton/First_Api/register")
    Alamofire.request("http://192.168.1.19/skeleton/First_Api/register", method: .post, parameters: Dic, encoding: URLEncoding.default).responseJSON{response in
            var erre:Error?
        switch response.result{
        case .success(let json):
            print(json)
            DispatchQueue.main.async {
//                let alert = UIAlertController(title: "Eroor", message: "Nothing", preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
//                self.present(alert, animated: true, completion: nil)
                print(Dic)
            }
        case.failure(let Error):
            erre=Error
            print(Error)
        }
        
    }

}

    @IBAction func GoLoginView(_ sender: Any) {
        let obj = self.storyboard?.instantiateViewController(withIdentifier: "LoginView")as! LoginView
        self.navigationController?.pushViewController(obj, animated: true)
        
    }
}
