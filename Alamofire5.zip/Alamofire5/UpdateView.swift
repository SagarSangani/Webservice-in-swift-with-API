//
//  UpdateView.swift
//  Alamofire5
//
//  Created by admin on 17/11/17.
//  Copyright © 2017 360techno. All rights reserved.
//

import UIKit
import Alamofire

class UpdateView: UIViewController {
    @IBOutlet var searchTF: UITextField!
    var search : NSDictionary = ["" : ""]
    var arrays = NSMutableArray()
    

    @IBOutlet var idlab: UILabel!
    @IBOutlet var nameTF: UITextField!
    @IBOutlet var MailTF: UITextField!
    @IBOutlet var UPdateBTN: UIButton!
    
    var namestr = NSString()
    var mailstr = NSString()
    var idstr = NSString()
    
    var samplestr = NSString()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameTF.text = namestr as String
        MailTF.text = mailstr as String
        idlab.text = idstr as String
        samplestr = NSString .localizedStringWithFormat("%@", idlab.text!)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func UpdateBTN(_ sender: Any) {
        
        let obj = ["user_id" : idlab.text!,
                   "username" : nameTF.text!,
                   "email" : MailTF.text!]

        
        Alamofire.request("http://192.168.1.19/skeleton/First_Api/updatedetails", method: .post, parameters: obj, encoding: URLEncoding.default).responseJSON{response in var erre:Error?
                        switch response.result{
                        case .success(let json):
                            print(json)
                            DispatchQueue.main.async
                                {
            
                            }
                        case.failure(let Error):
                            erre=Error
                            print(erre as Any)
                        }
                        
                        self.navigationController?.popViewController(animated: true)
                    }

    }
    
    
    @IBAction func next(_ sender: Any) {
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "UploadImage") as! UploadImage
        obj.strobj = samplestr as NSString
        self.navigationController?.pushViewController(obj, animated: true)
        
    }

    
    
    @IBAction func searchBTN(_ sender: Any) {
        
        let dic=["username":searchTF.text!]
        
        Alamofire.request("http://192.168.1.19/skeleton/First_Api/usersearch", method: .post, parameters: dic, encoding: URLEncoding.default).responseJSON { response in
            var err: Error?
            switch response.result {
            case .success(let json):
                print(json)
                DispatchQueue.main.async {
                    self.search = json as! NSDictionary
                    print("searchdis", self.search)
                    self.arrays = NSMutableArray(object:self.search["qry"] as! NSArray )
                    
                    
                }
            case.failure(let error):
                err=error
                print(err as Any)
            }
    }
        
    }

}
