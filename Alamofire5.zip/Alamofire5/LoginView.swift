//
//  LoginView.swift
//  Alamofire5
//
//  Created by admin on 16/11/17.
//  Copyright © 2017 360techno. All rights reserved.
//

import UIKit
import Alamofire


class LoginView: UIViewController {

    @IBOutlet var Uname: UITextField!
    @IBOutlet var pass: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func LoginBTN(_ sender: Any) {
        
        let dic = ["Username":Uname.text!,"Password":pass.text!]
    Alamofire.request("http://192.168.1.19/skeleton/First_Api/login", method: .post, parameters: dic, encoding: URLEncoding.default).responseJSON{response in
            var erre:Error?
            switch response.result{
            case .success(let json):
                print(json)
                DispatchQueue.main.async {
                    //                let alert = UIAlertController(title: "Eroor", message: "Nothing", preferredStyle: .alert)
                    //                alert.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
                    //                self.present(alert, animated: true, completion: nil)
                    print(dic)
                }
            let obj = self.storyboard?.instantiateViewController(withIdentifier: "ShowDataView")
            self.navigationController?.pushViewController(obj!, animated: true)
            case.failure(let Error):
                erre=Error
                print(Error)
            }
            
        }
}
}
