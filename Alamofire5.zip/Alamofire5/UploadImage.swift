//
//  UploadImage.swift
//  Alamofire5
//
//  Created by technosoft on 17/11/17.
//  Copyright © 2017 360techno. All rights reserved.
//

import UIKit
import Alamofire

class UploadImage: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    @IBOutlet var imgView: UIImageView!

    @IBOutlet var nothing: UILabel!
    var strobj = NSString()
    
    
    let imgpickr=UIImagePickerController()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nothing.text = (strobj as NSString) as String
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
       @IBAction func photoselect(_ sender: Any) {
       // let alr :UIAlertController=UIAlertController(title: " ", message: "change from photos", preferredStyle: .actionSheet)
        //let choosephoto :UIAlertAction=UIAlertAction(title: "choose from photos", style:.default) { (UIAlertAction) in
            self.imgpickr.allowsEditing = false
            
            self.imgpickr.delegate = self
            
            self.imgpickr .sourceType=UIImagePickerControllerSourceType.photoLibrary
            self.present(self.imgpickr, animated: true, completion: nil)
            //alr .dismiss(animated: true, completion: nil)
        //}
        
        //self.present(alr, animated: true, completion: nil)
        
//        alr.addAction(choosephoto)
//        let clickphoto :UIAlertAction=UIAlertAction(title: "click for photos", style:.default) { (UIAlertAction) in
//            self.imgpickr.allowsEditing = false
//            
//            self.imgpickr.delegate = self
//            
//            self.imgpickr .sourceType=UIImagePickerControllerSourceType.camera
//            self.present(self.imgpickr, animated: true, completion: nil)
//            alr .dismiss(animated: true, completion: nil)
//            
//        }
//        
//        alr.addAction(clickphoto)
//        
//        let cancel :UIAlertAction=UIAlertAction(title: "cancel", style:.default) { (UIAlertAction) in
//            alr .dismiss(animated: true, completion: nil)
//            
//        }
//        
//        alr.addAction(cancel)
//        self.present(imgpickr, animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        imgView.image = chosenImage
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    @IBAction func uploadIMG(_ sender: Any) {
                let uploaddic = ["user_id":nothing.text!] as [String:String]
        
                Alamofire.upload(multipartFormData: { MultipartFormData in
        
                    let image :Data = UIImageJPEGRepresentation(self.imgView.image!, 1.0)!
        
                    MultipartFormData.append(image, withName: "image" , fileName: "image.jpeg" , mimeType: "image/jpeg")
                    for(key,value) in uploaddic{
        
                        MultipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)}
        
                }, to: "http://192.168.1.19/skeleton/First_Api/uploadImage", encodingCompletion: {
                    EncodingResult in
                    switch EncodingResult{
                    case .success(let upload, _, _):
                        upload.responseJSON { response in
                            debugPrint("SUCCESS RESPONSE: \(response)")
                        }
                    case .failure(let encodingError):
        
                        print("ERROR RESPONSE: \(encodingError)")
        
                    }        })
            }
            
        
    }
    
    
    








