//
//  ShowDataView.swift
//  Alamofire5
//
//  Created by admin on 16/11/17.
//  Copyright © 2017 360techno. All rights reserved.
//

import UIKit
import Alamofire

class ShowDataView: UIViewController,UITableViewDelegate,UITableViewDataSource{
    @IBOutlet var tblview : UITableView?
    var Dic : NSDictionary = ["" : ""]
    var array1 = NSMutableArray()
    //array = NSMutableArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        Alamofire.request("http://192.168.1.19/skeleton/First_Api/getuserdetails", method: .post, parameters: nil, encoding: URLEncoding.default).responseJSON{response in
            var erre:Error?
            switch response.result{
            case .success(let json):
                print(json)
                DispatchQueue.main.async
                {
                self.Dic = json as! NSDictionary
                    
                self.array1 = NSMutableArray (array: self.Dic["query"] as! NSArray)
                    
                self.tblview?.reloadData()
                }
            case.failure(let Error):
                erre=Error
                print(Error)
            }
            
        }

    }
    
    
    //⚽⚽⚽⚽⚽⚽⚽
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int
    {
        return self.array1.count
        
    }
    
    //⚽⚽⚽⚽⚽⚽⚽
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
     {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let tblData = array1 [indexPath.row] as! NSDictionary
        cell?.textLabel?.text = tblData["username"] as? String
        //tblview?.reloadData()
        return cell!
        
    }
    
    //⚽⚽⚽⚽⚽⚽⚽
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)  {
        
    let obj = self.storyboard?.instantiateViewController(withIdentifier: "UpdateView") as! UpdateView
        let tblData = array1 [indexPath.row] as! NSDictionary
        obj.namestr = tblData["username"] as! NSString
        obj.mailstr = tblData["email"] as! NSString
        obj.idstr = tblData["user_id"] as! NSString
    self.navigationController?.pushViewController(obj, animated: true)
        
}

}
