//
//  tableCellClass.swift
//  Alamofire5
//
//  Created by admin on 16/11/17.
//  Copyright © 2017 360techno. All rights reserved.
//

import UIKit

class tableCellClass: UITableViewCell {

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
